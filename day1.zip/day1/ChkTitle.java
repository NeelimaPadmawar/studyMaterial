package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChkTitle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/NEELIMA/softwares/chromedriver101/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		String baseUrl="https://www.selenium.dev/";
		String expectedTitle="Selenium";
		
		
		driver.get(baseUrl);
		String actualTitle=driver.getTitle();
		System.out.println(driver.getTitle());
		if(expectedTitle.contentEquals(actualTitle))
		{
			System.out.println("Test Passed");
		}
		else
		{
			System.out.println("Test Failed");
		}
		
		//driver.close();
	}

}
