package day1;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/NEELIMA_CAPGEMINI/softwares/chromedriver101/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("file:///D:/NEELIMA_CAPGEMINI/SELENIUM_FINAL/students_SELENIUM_TDD%20BDD/students_SELENIUM_TDD%20BDD/Lesson%205-HTML%20Pages/PopupWin.html");
		
		String parentWindow = driver.getWindowHandle().toString();
		
		driver.findElement(By.name("Open")).click();
		driver.switchTo().window("PopupWindow");
		driver.close();
		
		driver.switchTo().window(parentWindow);
		driver.close();

	}

}
