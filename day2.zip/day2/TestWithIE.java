package day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class TestWithIE {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.ie.driver", "C:/Users/Admin/Downloads/IEDriverServer_x64_3.5.1/IEDriverServer.exe");
		
		
		WebDriver driver=new InternetExplorerDriver();
		
		 driver.manage().window().maximize();
		 driver.get("https://www.selenium.dev/");
	
		
	}

}
