package day2;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestWithFireFox {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "C:/Users/Admin/Downloads/geckodriver-v0.31.0-win64/geckodriver.exe");
		//download the file from-> https://github.com/mozilla/geckodriver/releases
		
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.selenium.dev/");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);		
		//Sets the amount of time to wait for a page load to complete before throwing an error 
		
		System.out.println(driver.getTitle());
	}
}
