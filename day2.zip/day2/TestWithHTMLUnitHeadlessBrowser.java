package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class TestWithHTMLUnitHeadlessBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HtmlUnitDriver driver = new HtmlUnitDriver();
		 
		
		driver.get("https://www.google.com/");
 		System.out.println("Title of the page is -> " + driver.getTitle());
 
		// find the search edit box on the google page
		WebElement searchBox = driver.findElement(By.name("q"));
 
		// type in Selenium
		searchBox.sendKeys("Selenium");
 
		// find the search button
		WebElement button = driver.findElement(By.name("btnK"));
 
		// Click the button
		button.click();
		
		System.out.println("Title of the page is -> " + driver.getTitle());
	}
}
