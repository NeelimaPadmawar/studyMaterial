package day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTillAlertPresent {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:/NEELIMA/softwares/chromedriver101/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
				 
		driver.get("file:///D:/NEELIMA/SELENIUM_FINAL/students_SELENIUM_TDD%20BDD/students_SELENIUM_TDD%20BDD/Lesson%205-HTML%20Pages/WorkingWithForms.html");
				
	
				driver.findElement(By.name("txtPwd")).sendKeys("nee");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				driver.findElement(By.className("Format")).sendKeys("nee1");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				driver.findElement(By.className("Format")).sendKeys(Keys.TAB);
			
				WebDriverWait wait = new WebDriverWait(driver, 15);		//explicit wait object is created
				wait.until(ExpectedConditions.alertIsPresent());
				
				driver.switchTo().alert().getText();
				driver.switchTo().alert().accept();
				
				//enter correct pwd.

				 wait.until(ExpectedConditions.elementToBeClickable(By.name("submit")));
			        driver.findElement(By.id("searchButton")).click();
				
				
				driver.close();
	}

}
